import React from 'react'

const Input = () => {
  return (
    <div>Input</div>
  )
}

export default Input