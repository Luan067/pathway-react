import React from 'react'

const Label = () => {
  return (
    <div>Label</div>
  )
}

export default Label